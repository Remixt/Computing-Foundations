#Computing Foundations
### Programs completed while in computing foundations courses at UNT.

## Traveling-Salesperson
Completed Computiting Foundations assignment for the traveling salesman problem.
Algorithmic C++ program that answers the commonly asked traveling salesman problem.
